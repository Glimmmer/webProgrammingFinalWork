window.model = {
    data: {
        items: [
            // {mess:'', complete: false}
        //    mess保存todo条目的信息，complete标记是否已完成
        ],
        msg: '',
        filter: 'All'
    },
    TOKEN: 'Lang Runxuan'

    // data provider interface
    // init: null
    // flush: null
};